/* MELK Studio — app logic. Talks to the strip through Melk.Link + Melk.protocol. */
(function () {
  'use strict';
  const P = Melk.protocol;
  const link = new Melk.Link();
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => Array.from(document.querySelectorAll(s));
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  /* ---------- colour helpers ---------- */
  function hsv2rgb(h, s, v) {
    const f = (n) => { const k = (n + h / 60) % 6; return v - v * s * Math.max(0, Math.min(k, 4 - k, 1)); };
    return [Math.round(f(5) * 255), Math.round(f(3) * 255), Math.round(f(1) * 255)];
  }
  function rgb2hsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0;
    if (d) {
      if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
      h *= 60; if (h < 0) h += 360;
    }
    return [h, mx ? d / mx : 0, mx];
  }
  const hex2 = (n) => n.toString(16).padStart(2, '0');
  const rgb2hex = (r, g, b) => ('#' + hex2(r) + hex2(g) + hex2(b)).toUpperCase();
  function hex2rgb(h) {
    const m = /^#?([0-9a-f]{6})$/i.exec(h.trim());
    if (!m) return null;
    const n = parseInt(m[1], 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  /* ---------- state ---------- */
  const AMBIENT = () => [
    { id: 'amb1', name: 'Ambient flow', speed: 1, steps: [['#FF8A3D', 14000, 5000], ['#FF4D7A', 14000, 5000], ['#B14DFF', 14000, 5000], ['#4A5BFF', 14000, 5000], ['#1FC8C0', 14000, 5000], ['#3DDC97', 14000, 5000], ['#FFC15A', 14000, 5000]] },
    { id: 'amb2', name: 'Ambient night', speed: 1, steps: [['#FF6A2B', 18000, 8000], ['#C2245E', 18000, 8000], ['#5B2BB8', 18000, 8000], ['#1F3FBF', 18000, 8000], ['#0E7C86', 18000, 8000]] },
  ].map((q) => ({ id: q.id, name: q.name, speed: q.speed, steps: q.steps.map(([c, fade, hold]) => ({ c, fade, hold })) }));
  const PRESET_SEQS = () => [
    { id: 'p1', name: 'Slow sunset', speed: 1, steps: [['#FF7A18', 3000, 1200], ['#FF2E63', 3000, 1200], ['#5B2A86', 3000, 1200], ['#1B1464', 3000, 1200]] },
    { id: 'p2', name: 'Breathing', speed: 1, steps: [['#FFB347', 2200, 300], ['#2A1500', 2200, 300]] },
    { id: 'p3', name: 'Candle', speed: 1, steps: [['#FF9A2E', 220, 140], ['#FF7A18', 260, 90], ['#FFB347', 200, 180], ['#FF8A24', 240, 110]] },
    { id: 'p4', name: 'Rainbow', speed: 1, steps: [['#FF0000', 1400, 0], ['#FFE600', 1400, 0], ['#00D26A', 1400, 0], ['#00D1FF', 1400, 0], ['#2F4BFF', 1400, 0], ['#D400FF', 1400, 0]] },
    { id: 'p5', name: 'Party flash', speed: 1, steps: [['#FF0055', 0, 260], ['#00E5FF', 0, 260], ['#FFE600', 0, 260]] },
  ].map((q) => ({ id: q.id, name: q.name, speed: q.speed, steps: q.steps.map(([c, fade, hold]) => ({ c, fade, hold })) }));

  const DEFAULT_SCENES = () => [
    { id: 'relax', name: 'Relax', type: 'seq', seq: 'amb1', br: 55 },
    { id: 'movie', name: 'Movie', type: 'color', color: '#FF9A4D', br: 18 },
    { id: 'reading', name: 'Reading', type: 'white', warm: 15, br: 75 },
    { id: 'dinner', name: 'Dinner', type: 'seq', seq: 'p3', br: 35 },
    { id: 'party', name: 'Party', type: 'music', style: 'spectrum', br: 100 },
    { id: 'focus', name: 'Focus', type: 'white', warm: 80, br: 85 },
    { id: 'morning', name: 'Morning', type: 'color', color: '#FFC15A', br: 60 },
    { id: 'sleep', name: 'Sleep', type: 'seq', seq: 'amb2', br: 12, sleep: 60 },
    { id: 'c-night', name: 'Night drive', type: 'color', color: '#FF9A4D', br: 10 },
    { id: 'c-cruise', name: 'Cruise', type: 'seq', seq: 'amb2', br: 20 },
    { id: 'c-chill', name: 'Parked chill', type: 'seq', seq: 'amb1', br: 40 },
  ];
  const DEF = {
    on: true, h: 33, s: 0.72, br: 80, speed: 50, warm: 50,
    palette: ['#FFB347', '#FF4D6D', '#7C5CFF', '#2EC4B6', '#FFFFFF'],
    flowSec: 60, modeNames: {}, modeHidden: {}, modeFav: {}, seqs: null, scenes: null, auto: false, carSeeded: false, fadeMs: 1500, sunDim: false, sunCap: 25, geo: null, sunState: 'day', dayBr: 80, showAll: false, tab: 'color', musicStyle: 'pulse', sens: 60, djInterval: 7, autoStyle: 'time', autoInterval: 45, preserveHardware: false, modePersistent: {'128':true}, persistentOnly: false, powerProfile: 'current', nativeTested: {}, beatGate: 55, beatCooldown: 360, beatCountView: 0, routines: [], routineEnabled: false, routineLast: {},
  };
  let S;
  try { S = Object.assign({}, DEF, JSON.parse(localStorage.getItem('melk.studio.v1') || '{}')); } catch (e) { S = Object.assign({}, DEF); }
  if (!Array.isArray(S.routines)) S.routines = [];
  if (!S.routineLast || typeof S.routineLast !== 'object') S.routineLast = {};
  if (!S.seqs) S.seqs = AMBIENT().concat(PRESET_SEQS());
  else AMBIENT().reverse().forEach((q) => { if (!S.seqs.some((x) => x.id === q.id)) S.seqs.unshift(q); });
  if (!Array.isArray(S.scenes)) S.scenes = DEFAULT_SCENES();
  if (!S.carSeeded) { DEFAULT_SCENES().filter((q) => q.id.indexOf('c-') === 0).forEach((q) => { if (!S.scenes.some((x) => x.id === q.id)) S.scenes.push(q); }); S.carSeeded = true; }
  const save = () => { try { localStorage.setItem('melk.studio.v1', JSON.stringify(S)); } catch (e) { /* storage unavailable */ } };

  // While OFF, suppress any delayed colour/brightness/mode writes left by effects.
  const nativeSend = link.send.bind(link);
  link.send = (bytes, key) => {
    if (!S.on && key !== 'power') return;
    return nativeSend(bytes, key);
  };
  let activeMode = null;
  let driver = null; // running custom effect or music
  let activeScene = null, curSeqId = null;

  const curRGB = () => hsv2rgb(S.h, S.s, 1);

  /* ---------- toast ---------- */
  let toastT;
  function toast(msg) {
    const t = $('#toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2600);
  }

  /* ---------- render hero ---------- */
  function paint(rgb, level) {
    const root = document.documentElement.style;
    root.setProperty('--glow', `rgb(${rgb[0]},${rgb[1]},${rgb[2]})`);
    root.setProperty('--glow-a', String(clamp(level, 0.05, 1)));
  }
  function render() {
    const rgb = curRGB();
    if (!driver) paint(rgb, S.br / 100);
    $('.app').classList.toggle('off', !S.on);
    $('#roHex').textContent = driver ? driver.label : activeMode !== null ? modeLabel(activeMode) : rgb2hex(...rgb);
    $('#roSub').textContent = S.on ? (activeMode !== null ? 'Running on the strip' : driver ? 'Custom effect' : 'Brightness ' + S.br + '%') : 'Strip is off';
    $('#btnPower').setAttribute('aria-pressed', String(S.on));
    $('#btnPower').setAttribute('aria-label', S.on ? 'Turn strip OFF' : 'Turn strip ON');
    $('#carBr').textContent = S.br + '%';
    $('#br').value = S.br; $('#brOut').textContent = S.br + '%';
    $('#rr').value = rgb[0]; $('#gg').value = rgb[1]; $('#bb').value = rgb[2];
    $('#rOut').textContent = rgb[0]; $('#gOut').textContent = rgb[1]; $('#bOut').textContent = rgb[2];
    if (document.activeElement !== $('#hexIn')) $('#hexIn').value = rgb2hex(...rgb);
    placeThumb();
  }

  /* ---------- sending ---------- */
  let lastRGB = [255, 179, 71], sentBr = S.br, fadeT = null, rampT = null;
  function sendRGB(c, key) { lastRGB = c; if (!S.on) return; link.send(P.color(c[0], c[1], c[2]), key || 'color'); }
  function pushColor() { sendRGB(curRGB()); }
  function sendBr(v) { sentBr = v; if (!S.on) return; link.send(P.brightness(v), 'bright'); }
  function cancelRamp() { clearInterval(rampT); rampT = null; }
  function pushBright() { cancelRamp(); sendBr(S.br); }
  const ease = (u) => u * u * (3 - 2 * u);
  function rampBright(to, ms, done) {
    cancelRamp();
    const from = sentBr;
    if (!ms || from === to || !link.ready) { sendBr(to); if (done) done(); return; }
    const t0 = performance.now();
    rampT = setInterval(() => {
      const u = Math.min(1, (performance.now() - t0) / ms);
      sendBr(Math.round(from + (to - from) * ease(u)));
      if (u >= 1) { cancelRamp(); if (done) done(); }
    }, 70);
  }
  function cancelFade() { clearInterval(fadeT); fadeT = null; }
  function fadeColor(to, ms) {
    cancelFade();
    const from = lastRGB.slice();
    if (!ms || !link.ready) { sendRGB(to); return; }
    const t0 = performance.now();
    fadeT = setInterval(() => {
      const u = Math.min(1, (performance.now() - t0) / ms), e = ease(u);
      const c = [0, 1, 2].map((i) => Math.round(from[i] + (to[i] - from[i]) * e));
      sendRGB(c); paint(c, S.br / 100);
      if (u >= 1) cancelFade();
    }, 70);
  }
  // Explicit user-selected power protocol. Never guess or switch automatically.
  function powerPacket(on) {
    if (S.powerProfile === 'elk') return Uint8Array.from(on
      ? [0x7e,0x00,0x04,0x01,0x00,0x00,0x00,0x00,0xef]
      : [0x7e,0x00,0x04,0x00,0x00,0x00,0xff,0x00,0xef]);
    return P.power(on);
  }
  function setPower(on) {
    on = Boolean(on);
    // Do not trust last scene/auto timers to manage physical power.
    if (!on) {
      S.auto = false;
      lastAuto = null;
      stopDriver();
      cancelFade();
      cancelRamp();
      activeScene = null;
      if (typeof sleepT !== 'undefined') {
        clearTimeout(sleepT); clearInterval(sleepTick);
        sleepT = null; sleepTick = null;
      }
      // The current BLE write may already be in flight; discard other queued work.
      if (link.queue) link.queue.length = 0;
    }
    S.on = on;
    // Key power separately, never piggyback it on queued colour/brightness writes.
    link.send(powerPacket(on), 'power');
    if (on) {
      // Avoid a fade timer racing the ON command (especially after a native effect).
      // Brightness follows power ON, with no RGB packet that could cancel hardware mode.
      sentBr = S.br;
      sendBr(S.br);
    }
    render(); save();
    toast(on ? 'Power ON command sent' : 'Power OFF command sent');
  }
  function stopDriver() {
    curSeqId = null; cancelFade();
    if (driver) { driver.stop(); driver = null; }
    $$('.card[data-seq]').forEach((c) => c.querySelector('[data-play]').textContent = 'Play');
    $('#flowBtn').textContent = 'Start';
    const mb = $('#musicBtn'); mb.setAttribute('aria-pressed', 'false'); mb.textContent = 'Start listening';
    $('#meter').style.width = '0';
  }
  function setColor(h, s, fromUser) {
    if (fromUser) { stopDriver(); activeMode = null; activeScene = null; renderModes(); renderScenes(); }
    S.h = h; S.s = s; render(); pushColor(); save();
  }
  function setRGB(r, g, b) { const [h, s] = rgb2hsv(r, g, b); setColor(h, s, true); }

  /* ---------- colour wheel ---------- */
  const wheel = $('#wheel'), thumb = $('#thumb');
  (function drawWheel() {
    const n = wheel.width, ctx = wheel.getContext('2d'), img = ctx.createImageData(n, n), R = n / 2;
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const dx = x - R + 0.5, dy = y - R + 0.5, r = Math.hypot(dx, dy), i = (y * n + x) * 4;
      if (r > R) { img.data[i + 3] = 0; continue; }
      let h = Math.atan2(dy, dx) * 180 / Math.PI; if (h < 0) h += 360;
      const c = hsv2rgb(h, Math.min(1, r / (R - 1)), 1);
      img.data[i] = c[0]; img.data[i + 1] = c[1]; img.data[i + 2] = c[2]; img.data[i + 3] = 255;
    }
    ctx.putImageData(img, 0, 0);
  })();
  function placeThumb() {
    const a = S.h * Math.PI / 180, r = S.s * 50; // percent of box radius
    thumb.style.left = (50 + Math.cos(a) * r) + '%';
    thumb.style.top = (50 + Math.sin(a) * r) + '%';
  }
  function wheelPick(e) {
    const b = wheel.getBoundingClientRect(), R = b.width / 2;
    const dx = e.clientX - b.left - R, dy = e.clientY - b.top - R;
    let h = Math.atan2(dy, dx) * 180 / Math.PI; if (h < 0) h += 360;
    setColor(h, clamp(Math.hypot(dx, dy) / R, 0, 1), true);
  }
  let wheelDown = false;
  wheel.addEventListener('pointerdown', (e) => { wheelDown = true; wheel.setPointerCapture(e.pointerId); wheelPick(e); });
  wheel.addEventListener('pointermove', (e) => { if (wheelDown) wheelPick(e); });
  wheel.addEventListener('pointerup', () => { wheelDown = false; });
  wheel.addEventListener('pointercancel', () => { wheelDown = false; });

  /* ---------- sliders ---------- */
  $('#br').addEventListener('input', (e) => { S.br = +e.target.value; render(); pushBright(); save(); });
  $('#warm').addEventListener('input', (e) => {
    stopDriver(); activeMode = null; activeScene = null; renderModes(); renderScenes();
    const w = +e.target.value; S.warm = w;
    $('#wOut').textContent = w < 35 ? 'Warm' : w > 65 ? 'Cool' : 'Neutral';
    link.send(P.whiteTemp(100 - w, w), 'white');
    const rgb = w < 50 ? [255, 255 - (50 - w) * 2.1 | 0, 255 - (50 - w) * 5.2 | 0] : [255 - (w - 50) * 1.6 | 0, 255 - (w - 50) * 0.7 | 0, 255];
    paint(rgb, S.br / 100); save();
  });
  ['rr', 'gg', 'bb'].forEach((id) => $('#' + id).addEventListener('input', () => setRGB(+$('#rr').value, +$('#gg').value, +$('#bb').value)));
  $('#hexIn').addEventListener('input', (e) => { const c = hex2rgb(e.target.value); if (c) setRGB(...c); });
  $('#sp').addEventListener('input', (e) => { S.speed = +e.target.value; $('#spOut').textContent = S.speed + '%'; link.send(P.speed(S.speed), 'speed'); save(); });
  $('#sp').value = S.speed; $('#spOut').textContent = S.speed + '%';

  $('#btnPower').addEventListener('click', () => setPower(!S.on));
  $('#forcePowerOn').addEventListener('click', () => setPower(true));
  $('#forcePowerOff').addEventListener('click', () => setPower(false));

  /* ---------- palette ---------- */
  let palEdit = false;
  function renderPalette() {
    const box = $('#palette'); box.innerHTML = '';
    S.palette.forEach((hex, i) => {
      const b = document.createElement('button');
      b.className = 'sw'; b.style.setProperty('--c', hex); b.type = 'button'; b.setAttribute('aria-label', palEdit ? 'Remove ' + hex : 'Use ' + hex);
      if (palEdit) { const x = document.createElement('span'); x.className = 'x'; x.textContent = '×'; b.appendChild(x); }
      b.addEventListener('click', () => {
        if (palEdit) { S.palette.splice(i, 1); save(); renderPalette(); } else setRGB(...hex2rgb(hex));
      });
      box.appendChild(b);
    });
    const add = document.createElement('button');
    add.className = 'sw add'; add.type = 'button'; add.textContent = '+'; add.setAttribute('aria-label', 'Save current colour');
    add.addEventListener('click', () => {
      const hex = rgb2hex(...curRGB());
      if (S.palette.includes(hex)) return toast('Already in your colours');
      S.palette.push(hex); save(); renderPalette(); toast('Saved ' + hex);
    });
    box.appendChild(add);
    $('#palEdit').textContent = palEdit ? 'Done' : 'Edit';
  }
  $('#palEdit').addEventListener('click', () => { palEdit = !palEdit; renderPalette(); });

  /* ---------- built-in modes ---------- */
  let modeEdit = false;
  function modeLabel(id) { return S.modeNames[id] || 'Mode ' + (id - P.MODE_FIRST + 1); }
  // Persistence annotations are recorded by the user after a power-cycle test.
  // Mode 128 is premarked because it was physically verified on this controller.
  S.modePersistent = S.modePersistent || {'128': true};
  S.persistentOnly = !!S.persistentOnly;
  function modePersistNote(id) { return S.modePersistent[id] ? ' · ✓ Offline tested' : ' · Not tested'; }
  function renderModes() {
    const ids = []; for (let i = P.MODE_FIRST; i <= P.MODE_LAST; i++) ids.push(i);
    ids.sort((a, b) => (S.modeFav[b] ? 1 : 0) - (S.modeFav[a] ? 1 : 0) || a - b);
    const grid = $('#modeGrid'); grid.innerHTML = '';
    ids.forEach((id) => {
      if (S.modeHidden[id] && !modeEdit) return;
      if (S.persistentOnly && !S.modePersistent[id] && !modeEdit) return;
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'tile' + (S.modeHidden[id] ? ' hidden' : '');
      b.textContent = modeLabel(id) + modePersistNote(id); b.setAttribute('aria-pressed', String(activeMode === id));
      if (S.modeFav[id]) { const st = document.createElement('span'); st.className = 'star'; st.textContent = '★'; b.appendChild(st); }
      b.addEventListener('click', () => modeEdit ? editMode(id) : runMode(id));
      grid.appendChild(b);
    });
    $('#modeEdit').textContent = modeEdit ? 'Done' : 'Rename';
    $('#persistentOnly').checked = !!S.persistentOnly;
    $('#modeHint').textContent = modeEdit
      ? 'Tap a mode to rename it, star it, or hide it.'
      : 'Only ✓ Offline tested modes have been confirmed after app close and strip power OFF/ON. Others need testing.';
  }
  function runMode(id) {
    stopDriver(); activeMode = id; activeScene = null; S.lastHardwareMode = id; save(); renderScenes(); link.send(P.mode(id), 'mode');
    link.send(P.speed(S.speed), 'speed'); renderModes(); render();
  }
  $('#persistentOnly').addEventListener('change', e => { S.persistentOnly = e.target.checked; save(); renderModes(); });
  $('#modeEdit').addEventListener('click', () => { modeEdit = !modeEdit; renderModes(); });

  /* ---------- dialog helper ---------- */
  const dlg = $('#dlg'), dlgForm = $('#dlgForm');
  function openDialog(html, onMount) {
    dlgForm.innerHTML = html; if (onMount) onMount(dlgForm);
    if (!dlg.open) dlg.showModal();
  }
  function closeDialog() { if (dlg.open) dlg.close(); }
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  function editMode(id) {
    openDialog(`
      <h3>Mode ${id - P.MODE_FIRST + 1}</h3>
      <label class="field"><span>Name</span><input class="text" name="n" value="${esc(S.modeNames[id] || '')}" maxlength="24" placeholder="Mode ${id - P.MODE_FIRST + 1}"></label>
      <label class="check"><input type="checkbox" name="f" ${S.modeFav[id] ? 'checked' : ''}><span>Star it (moves to the top)</span></label>
      <label class="check"><input type="checkbox" name="p" ${S.modePersistent[id] ? 'checked' : ''}><span>Verified: this mode survives app close AND power OFF/ON</span></label>
      <label class="check"><input type="checkbox" name="h" ${S.modeHidden[id] ? 'checked' : ''}><span>Hide it from the list</span></label>
      <div class="dlgActs"><button class="btn ghost" value="cancel">Cancel</button><button class="btn main" value="ok" id="okBtn">Save</button></div>`,
    (f) => {
      f.querySelector('#okBtn').addEventListener('click', (e) => {
        e.preventDefault();
        const n = f.n.value.trim(); if (n) S.modeNames[id] = n; else delete S.modeNames[id];
        if (f.f.checked) S.modeFav[id] = 1; else delete S.modeFav[id];
        if (f.h.checked) S.modeHidden[id] = 1; else delete S.modeHidden[id];
        if (f.p.checked) S.modePersistent[id] = true; else delete S.modePersistent[id];
        save(); renderModes(); closeDialog();
      });
    });
  }

  /* ---------- custom effects (sequences) ---------- */
  const lerp = (a, b, t) => a + (b - a) * t;
  function seqColor(seq, tMs) {
    const k = seq.speed || 1, st = seq.steps;
    const total = st.reduce((a, s) => a + s.fade + s.hold, 0) / k;
    let t = total > 0 ? tMs % total : 0;
    for (let i = 0; i < st.length; i++) {
      const prev = hex2rgb(st[(i + st.length - 1) % st.length].c), cur = hex2rgb(st[i].c);
      const fade = st[i].fade / k, hold = st[i].hold / k;
      if (t < fade) { const u0 = t / fade, u = u0 * u0 * (3 - 2 * u0); return [0, 1, 2].map((j) => Math.round(lerp(prev[j], cur[j], u))); }
      t -= fade;
      if (t < hold) return cur;
      t -= hold;
    }
    return hex2rgb(st[0].c);
  }
  function playSeq(seq) {
    if (!S.on) setPower(true);
    // Opt-in native mode. Only use an ID that the owner has tested on the physical controller.
    // Unlike RGB step loops, a native mode can keep running after the phone disconnects.
    if (Number.isInteger(seq.hardwareMode) && seq.hardwareMode >= P.MODE_FIRST && seq.hardwareMode <= P.MODE_LAST) {
      stopDriver();
      activeMode = seq.hardwareMode;
      S.lastHardwareMode = activeMode;
      save();
      link.send(P.mode(activeMode), 'mode');
      link.send(P.speed(S.speed), 'speed');
      renderModes(); render(); renderSeqs(seq.id);
      toast(seq.name + ': hardware mode ' + activeMode);
      return;
    }
    stopDriver(); activeMode = null; renderModes();
    if (!seq.steps.length) return toast('Add at least one colour step');
    const t0 = performance.now(), from = lastRGB.slice(), fin = S.fadeMs;
    const id = setInterval(() => {
      const el = performance.now() - t0;
      let c = seqColor(seq, el);
      if (fin && el < fin) { const e = ease(el / fin); c = [0, 1, 2].map((i) => Math.round(from[i] + (c[i] - from[i]) * e)); }
      sendRGB(c); paint(c, S.br / 100);
    }, 70);
    driver = { label: seq.name, stop() { clearInterval(id); } }; curSeqId = seq.id;
    render(); renderSeqs(seq.id);
  }
  function renderSeqs(playingId) {
    const list = $('#seqList'); list.innerHTML = '';
    if (!S.seqs.length) list.innerHTML = '<p class="hint">No effects yet. Press New effect to build one from your colours.</p>';
    S.seqs.forEach((q) => {
      const card = document.createElement('div'); card.className = 'card'; card.dataset.seq = q.id;
      const grad = q.steps.map((s) => `<i style="background:${s.c}"></i>`).join('');
      const modeHint = Number.isInteger(q.hardwareMode) ? `<small>Hardware mode ${q.hardwareMode} · may persist offline</small>` : '<small>Phone-driven · stops when disconnected</small>';
      card.innerHTML = `<div><b>${esc(q.name)}</b><div class="strip">${grad}</div>${modeHint}</div>
        <div class="acts"><button class="btn main" data-play type="button">${playingId === q.id ? 'Playing' : 'Play'}</button><button class="btn ghost" data-edit type="button">Edit</button></div>`;
      card.querySelector('[data-play]').addEventListener('click', () => playSeq(q));
      card.querySelector('[data-edit]').addEventListener('click', () => editSeq(q));
      list.appendChild(card);
    });
  }
  function editSeq(q) {
    const isNew = !q;
    const draft = q ? JSON.parse(JSON.stringify(q)) : { id: 'u' + Date.now(), name: '', speed: 1, steps: S.palette.slice(0, 3).map((c) => ({ c, fade: 1500, hold: 500 })) };
    const stepHtml = (s, i) => `<div class="step" data-i="${i}">
      <input type="color" value="${s.c.toLowerCase()}" aria-label="Colour ${i + 1}">
      <label>Fade in (ms)<input class="text" type="number" min="0" max="20000" step="100" value="${s.fade}" inputmode="numeric"></label>
      <label>Hold (ms)<input class="text" type="number" min="0" max="20000" step="100" value="${s.hold}" inputmode="numeric"></label>
      <button class="rm" type="button" aria-label="Remove step">×</button></div>`;
    const draw = (f) => {
      f.querySelector('.steps').innerHTML = draft.steps.map(stepHtml).join('');
      f.querySelectorAll('.step').forEach((el) => {
        const i = +el.dataset.i, [col, fade, hold] = el.querySelectorAll('input');
        col.addEventListener('input', () => { draft.steps[i].c = col.value.toUpperCase(); });
        fade.addEventListener('input', () => { draft.steps[i].fade = clamp(+fade.value || 0, 0, 20000); });
        hold.addEventListener('input', () => { draft.steps[i].hold = clamp(+hold.value || 0, 0, 20000); });
        el.querySelector('.rm').addEventListener('click', () => { draft.steps.splice(i, 1); draw(f); });
      });
    };
    openDialog(`
      <h3>${isNew ? 'New effect' : 'Edit effect'}</h3>
      <label class="field"><span>Name</span><input class="text" name="n" value="${esc(draft.name)}" maxlength="24" placeholder="Evening glow"></label>
      <label class="field"><span>Hardware mode (optional)</span>
        <select class="text" id="hwMode"><option value="">Phone-driven colours (original)</option>
        ${Array.from({length: P.MODE_LAST-P.MODE_FIRST+1}, (_,i)=>P.MODE_FIRST+i).map(id=>`<option value="${id}" ${draft.hardwareMode===id?'selected':''}>${id} — ${esc(modeLabel(id))}</option>`).join('')}</select></label>
      <p class="hint">Only link a mode after testing its actual animation. A hardware mode may survive power off/on; the colour steps below are not sent when one is selected. This does not save an arbitrary custom pattern to controller memory.</p>
      <div class="field"><span>Colour steps (phone-driven fallback)</span><div class="steps"></div></div>
      <button class="btn ghost" type="button" id="addStep">Add step</button>
      <label class="row"><span>Overall speed</span><output id="skOut">${draft.speed}×</output>
        <input type="range" id="sk" min="0.25" max="4" step="0.25" value="${draft.speed}"></label>
      <div class="dlgActs">
        ${isNew ? '' : '<button class="btn ghost" type="button" id="delSeq">Delete</button>'}
        <button class="btn ghost" value="cancel">Cancel</button><button class="btn main" id="okBtn" value="ok">Save and play</button></div>`,
    (f) => {
      draw(f);
      f.querySelector('#addStep').addEventListener('click', () => {
        const last = draft.steps[draft.steps.length - 1];
        draft.steps.push({ c: S.palette[draft.steps.length % S.palette.length] || '#FFFFFF', fade: last ? last.fade : 1500, hold: last ? last.hold : 500 }); draw(f);
      });
      f.querySelector('#sk').addEventListener('input', (e) => { draft.speed = +e.target.value; f.querySelector('#skOut').textContent = draft.speed + '×'; });
      const del = f.querySelector('#delSeq');
      if (del) del.addEventListener('click', () => { stopDriver(); S.seqs = S.seqs.filter((x) => x.id !== q.id); save(); renderSeqs(); render(); closeDialog(); });
      f.querySelector('#okBtn').addEventListener('click', (e) => {
        e.preventDefault();
        draft.name = f.n.value.trim() || 'My effect';
        const chosen = f.querySelector('#hwMode').value;
        if (chosen) draft.hardwareMode = Number(chosen);
        else delete draft.hardwareMode;
        if (!draft.steps.length && !chosen) return toast('Add at least one colour step');
        const i = S.seqs.findIndex((x) => x.id === draft.id);
        if (i >= 0) S.seqs[i] = draft; else S.seqs.push(draft);
        save(); closeDialog(); renderSeqs(); playSeq(draft);
      });
    });
  }
  $('#seqNew').addEventListener('click', () => editSeq(null));


  /* ---------- colour flow: slow, continuous walk through every hue ---------- */
  const fmtSec = (s) => s < 60 ? s + ' sec' : (s % 60 ? (s / 60).toFixed(1) : s / 60) + ' min';
  function playFlow() {
    if (!S.on) setPower(true);
    stopDriver(); activeMode = null; renderModes();
    const t0 = performance.now(), h0 = S.h;
    const id = setInterval(() => {
      const hue = (h0 + ((performance.now() - t0) / (S.flowSec * 1000)) * 360) % 360;
      const c = hsv2rgb(hue, 1, 1);
      sendRGB(c); paint(c, S.br / 100);
    }, 80);
    driver = { label: 'Colour flow', stop() { clearInterval(id); } };
    $('#flowBtn').textContent = 'Stop'; render();
  }
  $('#flowBtn').addEventListener('click', () => {
    if (driver && driver.label === 'Colour flow') { stopDriver(); render(); pushColor(); } else playFlow();
  });
  $('#flowSec').value = S.flowSec; $('#flowOut').textContent = fmtSec(S.flowSec);
  $('#flowSec').addEventListener('input', (e) => { S.flowSec = +e.target.value; $('#flowOut').textContent = fmtSec(S.flowSec); save(); });

  function setSeg(which) {
    const built = which === 'built';
    $('#segBuilt').setAttribute('aria-pressed', String(built)); $('#segMine').setAttribute('aria-pressed', String(!built));
    $('#fxBuilt').hidden = !built; $('#fxMine').hidden = built;
  }
  $('#segBuilt').addEventListener('click', () => setSeg('built'));
  $('#segMine').addEventListener('click', () => setSeg('mine'));

  /* ---------- music ---------- */
  // Smooth audio envelope, beat-driven colour changes and BLE rate limiting.
  const mus = { hue: S.h, avg: 0.05, fast: 0, slow: 0, env: 0.2, lastBeat: 0, lastTx: 0, lastHue: 0, lastRgb: null, lastDJ: 0, quiet: 0, beatCount: 0, mode: null };
  function musicFrame(input) {
    const bass = clamp(Number(input) || 0, 0, 1);
    const now = performance.now();
    const sensitivity = clamp(S.sens / 100, 0.05, 1);
    // Adaptive onset envelope. Native AudioLevel supplies bass intensity only;
    // this is onset detection, NOT full FFT or song BPM recognition.
    const floor = 0.025 + (1 - sensitivity) * 0.08;
    const energy = Math.max(0, bass - floor);
    mus.fast += (energy - mus.fast) * 0.38;
    mus.slow += (energy - mus.slow) * 0.035;
    mus.avg += (energy - mus.avg) * 0.04;
    const gate = 0.045 + (S.beatGate / 100) * 0.16;
    const onset = mus.fast - mus.slow;
    const beat = energy > gate && onset > 0.035 + (1 - sensitivity) * 0.022 &&
      mus.fast > Math.max(0.055, mus.slow * 1.48) && now - mus.lastBeat > S.beatCooldown;
    if (beat) { mus.lastBeat = now; mus.hue = (mus.hue + 47) % 360; mus.beatCount++; }
    const beatLamp = $('#beatLamp');
    if (beatLamp) beatLamp.textContent = beat ? '● BEAT ' + mus.beatCount : 'Beat count: ' + mus.beatCount;
    // Built-in controller patterns run on the strip; changing each beat restarts them.
    // Change no faster than the user-selected minimum interval, only on a strong beat.
    if (S.musicStyle === 'dj') {
      $('#meter').style.width = Math.round(clamp(energy * 220, 0, 100)) + '%';
      if (!link.ready || !beat || now - mus.lastDJ < S.djInterval * 1000) return;
      const favorites = Object.keys(S.modeFav).filter(k => S.modeFav[k] && +k >= P.MODE_FIRST && +k <= P.MODE_LAST).map(Number);
      const pool = favorites.length ? favorites : Array.from({length: P.MODE_LAST - P.MODE_FIRST + 1}, (_,i) => P.MODE_FIRST + i);
      const choices = pool.filter(x => x !== mus.mode);
      const mode = (choices.length ? choices : pool)[Math.floor(Math.random() * (choices.length || pool.length))];
      mus.mode = mode; mus.lastDJ = now;
      S.lastHardwareMode = mode; // Persist the choice in app storage; hardware power-on persistence is controller-dependent.
      link.send(P.mode(mode), 'mode');
      link.send(P.speed(S.speed), 'speed');
      $('#djStatus').textContent = 'Playing ' + modeLabel(mode) + (favorites.length ? ' (favourites)' : '');
      return;
    }
    const target = clamp(0.22 + energy * (1.2 + sensitivity), 0.22, 0.90);
    mus.env += (target - mus.env) * (target > mus.env ? 0.20 : 0.055);
    const spectrum = S.musicStyle === 'spectrum';
    if (spectrum && now - mus.lastHue > 110) {
      mus.hue = (mus.hue + 1.2) % 360;
      mus.lastHue = now;
    }
    const rgb = spectrum ? hsv2rgb(mus.hue, 0.92, mus.env) : hsv2rgb(S.h, S.s, mus.env);
    paint(rgb, mus.env);
    $('#meter').style.width = Math.round(mus.env * 100) + '%';
    if (now - mus.lastTx < 125) return;
    if (mus.lastRgb && Math.max(...rgb.map((v,i) => Math.abs(v - mus.lastRgb[i]))) < 7) return;
    mus.lastTx = now;
    mus.lastRgb = rgb;
    sendRGB(rgb);
  }
  function showListening() {
    const mb = $('#musicBtn'); mb.setAttribute('aria-pressed', 'true'); mb.textContent = 'Stop listening'; render();
  }
  async function startMusic() {
    stopDriver(); activeMode = null; renderModes();
    mus.avg = 0.05; mus.fast = 0; mus.slow = 0; mus.beatCount = 0; mus.env = 0.2; mus.lastTx = 0; mus.lastRgb = null; mus.lastDJ = 0; mus.mode = null;

    // Inside the APK: native microphone detection; requires RECORD_AUDIO permission.
    if (window.MelkAudio && window.MelkAudio.native) {
      try { await MelkAudio.start((f) => musicFrame(f.bass)); }
      catch (e) { return toast((e && e.message) || 'Audio access nahi mili'); }
      if (!S.on) setPower(true);
      driver = { label: 'Listening…', stop() { MelkAudio.stop(); } };
      return showListening();
    }

    // Browser: microphone only (hears the speaker, not earphones)
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return toast('This browser cannot use the microphone');
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } }); }
    catch (e) { return toast('Microphone permission denied. App Settings > Permissions > Microphone mein Allow karein.'); }
    if (!S.on) setPower(true);
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const an = ctx.createAnalyser(); an.fftSize = 256; an.smoothingTimeConstant = 0.6;
    ctx.createMediaStreamSource(stream).connect(an);
    const data = new Uint8Array(an.frequencyBinCount);
    const id = setInterval(() => {
      an.getByteFrequencyData(data);
      let bass = 0; for (let i = 1; i < 8; i++) bass += data[i]; bass /= 7 * 255;
      musicFrame(bass);
    }, 60);
    driver = { label: 'Listening…', stop() { clearInterval(id); stream.getTracks().forEach((t) => t.stop()); ctx.close(); } };
    showListening();
  }
  $('#musicBtn').addEventListener('click', () => {
    if (driver && driver.label === 'Listening…') { stopDriver(); render(); pushColor(); } else startMusic();
  });
  $('#djInterval').value = S.djInterval;
  $('#djIntervalOut').textContent = S.djInterval + ' s';
  $('#djInterval').addEventListener('input', e => { S.djInterval = +e.target.value; $('#djIntervalOut').textContent = S.djInterval + ' s'; save(); });
  $('#beatGate').value = S.beatGate;
  $('#beatGateOut').textContent = S.beatGate + '%';
  $('#beatGate').addEventListener('input', e => { S.beatGate = +e.target.value; $('#beatGateOut').textContent = S.beatGate + '%'; save(); });
  $('#beatCooldown').value = S.beatCooldown;
  $('#beatCooldownOut').textContent = S.beatCooldown + ' ms';
  $('#beatCooldown').addEventListener('input', e => { S.beatCooldown = +e.target.value; $('#beatCooldownOut').textContent = S.beatCooldown + ' ms'; save(); });
  $('#sen').value = S.sens; $('#senOut').textContent = S.sens + '%';
  $('#sen').addEventListener('input', (e) => { S.sens = +e.target.value; $('#senOut').textContent = S.sens + '%'; save(); });
  $$('[data-ms]').forEach((b) => {
    b.setAttribute('aria-pressed', String(b.dataset.ms === S.musicStyle));
    b.addEventListener('click', () => { S.musicStyle = b.dataset.ms; $$('[data-ms]').forEach((x) => x.setAttribute('aria-pressed', String(x === b))); save(); });
  });

  // Named effects referenced by b1scoito/elk-led-controller/src/effects.rs.
  // Send ONLY as an opt-in diagnostic, not as an automatic replacement for app scenes.
  const nativeEffects = [
    {id: 135, name: "RGB jump"},
    {id: 136, name: "Seven-colour jump"},
    {id: 137, name: "RGB crossfade"},
    {id: 138, name: "Seven-colour crossfade"},
    {id: 139, name: "Red crossfade"},
    {id: 140, name: "Green crossfade"},
    {id: 141, name: "Blue crossfade"},
    {id: 149, name: "Seven-colour blink"},
    {id: 150, name: "Red blink"},
    {id: 151, name: "Green blink"},
    {id: 152, name: "Blue blink"}
  ];
  const nativeSelect = $('#nativeEffectSelect');
  nativeEffects.forEach(effect => {
    const option = document.createElement('option');
    option.value = String(effect.id);
    option.textContent = effect.name + ' (0x' + effect.id.toString(16).toUpperCase() + ')';
    nativeSelect.appendChild(option);
  });
  S.nativeTested = S.nativeTested || {};
  const nativeStatus = $('#nativeEffectStatus');
  function renderNativeStatus() {
    const id = Number(nativeSelect.value);
    nativeStatus.textContent = S.nativeTested[id]
      ? 'User marked offline-tested: app close AND power OFF/ON. No firmware guarantee.'
      : 'Not tested for offline / power-cycle persistence.';
  }
  nativeSelect.addEventListener('change', renderNativeStatus);
  $('#nativeEffectVerified').addEventListener('click', () => {
    const id = Number(nativeSelect.value);
    if (!$('#labConfirm').checked) { nativeStatus.textContent = 'Enable Protocol Lab confirmation first.'; return; }
    if (!confirm('Did you test this exact effect after closing the app AND power cycling the strip?')) return;
    S.nativeTested[id] = true; save(); renderNativeStatus();
  });
  const profile = $('#powerProfile');
  profile.value = S.powerProfile === 'elk' ? 'elk' : 'current';
  function renderProfile() { $('#powerProfileStatus').textContent = profile.value === 'elk'
    ? 'ELK alternative selected. Test ON/OFF with strip connected before relying on it.'
    : 'Existing MELK packets selected (original default).'; }
  profile.addEventListener('change', () => {
    if (profile.value === 'elk' && !confirm('Only use ELK after independently testing both ELK ON and ELK OFF in Protocol Lab. Continue?')) {
      profile.value = S.powerProfile === 'elk' ? 'elk' : 'current'; return;
    }
    S.powerProfile = profile.value; save(); renderProfile();
  });
  renderProfile(); renderNativeStatus();

  // Protocol Lab: never change the production power/mode packet builders.
  // The user must explicitly opt in to each packet. Auto/music remain stopped.
  const labMode = $('#labModeSelect');
  for (let id = 128; id <= 155; id++) {
    const option = document.createElement('option');
    option.value = String(id); option.textContent = 'Mode ' + id + ' (0x' + id.toString(16).toUpperCase() + ')';
    labMode.appendChild(option);
  }
  const labOutput = $('#labOutput');
  const labPackets = {
    labElkOn: [0x7e,0x00,0x04,0x01,0x00,0x00,0x00,0x00,0xef],
    labElkOff: [0x7e,0x00,0x04,0x00,0x00,0x00,0xff,0x00,0xef],
    labOldOn: Array.from(P.power(true)),
    labOldOff: Array.from(P.power(false))
  };
  function labSend(bytes, label) {
    if (!$('#labConfirm').checked) { labOutput.textContent = 'Please enable the stationary test confirmation first.'; return; }
    if (link.state !== 'connected') { labOutput.textContent = 'Connect the real LED strip first (Demo mode cannot test hardware).'; return; }
    // Do not let a JS-generated effect or auto timer override this test.
    S.auto = false; lastAuto = null; stopDriver(); cancelFade(); cancelRamp();
    if (link.queue) link.queue.length = 0;
    // Diagnostic commands intentionally bypass the app's saved OFF write gate.
    // Keep stored S.on unchanged: these are raw hardware tests, not state verification.
    nativeSend(Uint8Array.from(bytes), 'power');
    labOutput.textContent = 'Sent ' + label + ': ' + P.hex(bytes) + '\nObserve physical strip. App power indicator may be out of sync. Use a confirmed ON command to recover.';
  }
  $('#nativeEffectTest').addEventListener('click', () => {
    const id = Number(nativeSelect.value);
    const effect = nativeEffects.find(e => e.id === id);
    if (!effect) return;
    // ELK documentation packet; intentionally not applied to standard numbered modes.
    labSend([0x7e,0x00,0x03,id,0x03,0x00,0x00,0x00,0xef], 'ELK native ' + effect.name);
    renderNativeStatus();
  });
  for (const [id, packet] of Object.entries(labPackets))
    $('#' + id).addEventListener('click', () => labSend(packet, $('#' + id).textContent.trim()));
  // Magic Lantern 6.11.10 DEX: BluetoothLEService.changeScene() creates
  // [7E,05,31,sceneId,07,FF,FF,01,EF]. This is NOT the numbered-mode opcode 03.
  // Test exactly one user-selected ID. No automatic sweep, no persisted claim.
  $('#magicSceneSend').addEventListener('click', () => {
    const field = $('#magicSceneId');
    const id = Number(field.value);
    if (!Number.isInteger(id) || id < 0 || id > 255) {
      labOutput.textContent = 'Scene ID must be an integer from 0 to 255.';
      return;
    }
    if (!confirm('Send one Magic Lantern native scene test command (scene ' + id + ')? This can change the physical LEDs.')) return;
    labSend([0x7e,0x05,0x31,id,0x07,0xff,0xff,0x01,0xef], 'Magic Lantern native scene ' + id);
  });
  $('#labElkMode').addEventListener('click', () => {
    const id = Number(labMode.value);
    if (!Number.isInteger(id) || id < 128 || id > 155) return;
    labSend([0x7e,0x00,0x03,id,0x03,0x00,0x00,0x00,0xef], 'ELK native mode ' + id);
  });

  // Read-only BLE diagnostic: do not send test commands or change the working connection.
  const diagBtn = $('#deviceDiagBtn');
  if (diagBtn) diagBtn.addEventListener('click', async () => {
    const out = $('#deviceDiagOut');
    if (link.state !== 'connected') { out.textContent = 'Pehle strip connect karein.'; return; }
    const info = ['Status: Connected', 'Name: ' + (link.name || 'Not reported'),
      'Device ID: ' + (link.deviceId || 'Not available'),
      'Protocol service: ' + (P.SERVICE || 'Unknown'),
      'Write characteristic: ' + (P.CHAR || 'Unknown')];
    try {
      const plugin = window.Capacitor && (window.Capacitor.Plugins || {}).BluetoothLe;
      if (plugin && link.deviceId && typeof plugin.getServices === 'function') {
        const result = await plugin.getServices({deviceId: link.deviceId});
        const services = Array.isArray(result && result.services) ? result.services : [];
        const suffix = (uuid) => String(uuid || '').slice(4, 8).toUpperCase();
        for (const service of services) {
          const tag = suffix(service.uuid);
          info.push('');
          info.push('Service: ' + tag + (tag === '1800' ? ' (Generic Access)' : tag === 'FFF0' ? ' (LED Controller)' : ''));
          for (const characteristic of (service.characteristics || [])) {
            const ctag = suffix(characteristic.uuid);
            const props = characteristic.properties || {};
            const flags = ['read', 'write', 'writeWithoutResponse', 'notify'].filter((key) => props[key]);
            info.push('  ' + ctag + ': ' + (flags.join(', ') || 'no flags'));
          }
        }
        if (!services.length) info.push('GATT service list is empty');
      } else info.push('Additional GATT details: Not exposed by current adapter');
    } catch (e) { info.push('GATT details unavailable: ' + (e.message || e)); }
    info.push('');
    info.push('Exact model: Controller ne report nahi kiya');
    out.textContent = info.join('\n');
  });

  /* ---------- studio ---------- */
  let sleepT = null, sleepEnd = 0, sleepTick = null;
  function setSleep(min) {
    clearTimeout(sleepT); clearInterval(sleepTick);
    $$('#sleepSeg button').forEach((b) => b.setAttribute('aria-pressed', String(+b.dataset.min === min)));
    if (!min) { $('#sleepInfo').textContent = 'Off'; return; }
    sleepEnd = Date.now() + min * 60000;
    const upd = () => { $('#sleepInfo').textContent = 'Off in ' + Math.max(1, Math.ceil((sleepEnd - Date.now()) / 60000)) + ' min'; };
    upd(); sleepTick = setInterval(upd, 15000);
    sleepT = setTimeout(() => {
      clearInterval(sleepTick); stopDriver(); setPower(false);
      $('#sleepInfo').textContent = 'Off'; setSleep(0); toast('Sleep timer: strip turned off');
    }, min * 60000);
  }
  $$('#sleepSeg button').forEach((b) => b.addEventListener('click', () => setSleep(+b.dataset.min)));

  /* ---------- v1.1.0 smart routines: foreground only ---------- */
  const routineStatus = $('#routineStatus');
  const routineList = $('#routineList');
  const routineScene = $('#routineScene');
  function refreshRoutineOptions() {
    routineScene.innerHTML = '<option value="off">Turn lights OFF</option>';
    S.scenes.forEach(sc => { const o=document.createElement('option'); o.value=sc.id; o.textContent=sc.name; routineScene.appendChild(o); });
  }
  function renderRoutines() {
    refreshRoutineOptions();
    $('#routineEnabled').checked = !!S.routineEnabled;
    routineList.innerHTML = '';
    S.routines.forEach((r,i) => {
      const item=document.createElement('div'); item.className='routine-item';
      const label=document.createElement('span');
      const scene=S.scenes.find(sc=>sc.id===r.scene);
      label.textContent = r.time + ' · ' + (r.scene==='off' ? 'Lights OFF' : scene ? scene.name : 'Missing scene');
      const del=document.createElement('button'); del.type='button'; del.className='btn ghost'; del.textContent='Remove';
      del.addEventListener('click',()=>{ S.routines.splice(i,1); save(); renderRoutines(); });
      item.append(label,del); routineList.appendChild(item);
    });
    routineStatus.textContent = S.routineEnabled
      ? 'Enabled. Runs only while the app is open AND the strip is connected. Missed schedules are skipped.'
      : 'Disabled. Existing Sleep Timer and sunset dimming are unchanged.';
  }
  $('#routineEnabled').addEventListener('change', e => { S.routineEnabled = e.target.checked; save(); renderRoutines(); });
  $('#routineAdd').addEventListener('click', () => {
    const time = $('#routineTime').value;
    const scene = routineScene.value;
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) return toast('Choose a valid time');
    if (S.routines.length >= 12) return toast('Maximum 12 routines');
    if (S.routines.some(r => r.time===time && r.scene===scene)) return toast('Already added');
    S.routines.push({time,scene}); S.routines.sort((a,b)=>a.time.localeCompare(b.time)); save(); renderRoutines(); toast('Routine saved');
  });
  function tickRoutines() {
    if (!S.routineEnabled || !link.ready || document.hidden) return;
    const d = new Date(); const hh = String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');
    const date = d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
    for (const r of S.routines) {
      const key = date + '|' + r.time + '|' + r.scene;
      if (r.time !== hh || S.routineLast[key]) continue;
      S.routineLast = {[key]:true}; save(); // mark once before acting; never repeat same minute
      if (r.scene === 'off') { setPower(false); renderScenes(); }
      else runSceneId(r.scene);
      toast('Routine: ' + (r.scene==='off' ? 'Lights OFF' : r.scene));
      break;
    }
  }
  setInterval(tickRoutines, 15000);
  renderRoutines();

  const rawIn = $('#rawMode');
  const sendRaw = () => { const id = clamp(Math.round(+rawIn.value || 0), 0, 255); rawIn.value = id; stopDriver(); activeMode = null; link.send(P.mode(id), 'mode'); renderModes(); toast('Sent mode ' + id); };
  $('#rawGo').addEventListener('click', sendRaw);
  $('#rawNext').addEventListener('click', () => { rawIn.value = clamp((+rawIn.value || 0) + 1, 0, 255); sendRaw(); });

  $('#showAll').checked = !!S.showAll;
  $('#showAll').addEventListener('change', (e) => { S.showAll = e.target.checked; save(); });
  $('#demoBtn').addEventListener('click', () => { if (link.state === 'connected') link.disconnect(); link.startDemo(); toast('Demo strip on. Nothing is sent over Bluetooth.'); });

  $('#expBtn').addEventListener('click', () => { $('#backup').value = JSON.stringify(S); toast('Copy the text below to keep a backup'); });
  $('#impBtn').addEventListener('click', () => {
    try {
      const o = JSON.parse($('#backup').value);
      if (typeof o !== 'object' || !o || Array.isArray(o)) throw new Error('bad');
      S = Object.assign({}, DEF, o); if (!Array.isArray(S.seqs)) S.seqs = AMBIENT().concat(PRESET_SEQS());
      save(); stopDriver(); renderAll(); toast('Settings imported');
    } catch (e) { toast('That text is not valid settings'); }
  });

  const logLines = [];
  link.addEventListener('tx', (e) => {
    logLines.unshift(e.detail); logLines.length = Math.min(logLines.length, 10);
    $('#log').textContent = logLines.join('\n');
  });
  link.addEventListener('error', (e) => toast('Write failed: ' + (e.detail && e.detail.message || 'unknown error')));
  link.addEventListener('lost', () => toast('Could not reconnect. Tap Connect strip.'));
  link.addEventListener('restored', () => toast('Reconnected'));
  document.addEventListener('visibilitychange', () => { if (!document.hidden) link.resume(); });

  /* ---------- connection ---------- */
  link.addEventListener('state', (e) => {
    const { state, name } = e.detail, chip = $('#btnConn');
    chip.dataset.s = state;
    $('#connLabel').textContent = state === 'connected' ? name : state === 'demo' ? 'Demo strip' : state === 'connecting' ? (link.reconnecting ? 'Reconnecting…' : 'Connecting…') : 'Connect strip';
    if (link.ready) {
      // Opt-in: do not override an effect that the controller itself restored at power-on.
      if (S.preserveHardware && !S.auto && !pendingScene) {
        toast('Connected: keeping controller effect');
        return;
      }
      // Restore the saved power state; no brightness/RGB traffic while OFF.
      link.send(powerPacket(S.on), 'power'); sentBr = S.br; if (S.on) pushBright();
      if (activeMode !== null) { link.send(P.mode(activeMode), 'mode'); link.send(P.speed(S.speed), 'speed'); } else if (!driver) pushColor();
      sunCheck();
      if (pendingScene) { const id = pendingScene; pendingScene = null; setTimeout(() => runSceneId(id), 700); }
      if (S.auto) { lastAuto = null; setTimeout(() => runAuto(true), 600); }
    }
  });
  $('#btnConn').addEventListener('click', async () => {
    if (link.state === 'connected' || link.state === 'demo') return link.disconnect();
    if (link.state === 'connecting' && !link.reconnecting) return;   // native: a tap during auto-reconnect starts a fresh connect
    if (!link.supported) { link.startDemo(); return toast('No Web Bluetooth here. Demo mode is on.'); }
    try { await link.connect(S.showAll); toast('Connected to ' + link.name); }
    catch (err) { if (err && err.name !== 'NotFoundError') toast(err.message || 'Could not connect'); }
  });

  /* ---------- tabs ---------- */
  function showTab(t) {
    S.tab = t; save();
    if (t === 'studio') renderPersistentMapper();
    $$('.tabs button').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.tab === t)));
    ['color', 'fx', 'music', 'studio'].forEach((n) => { $('#tab-' + n).hidden = n !== t; });
  }
  $$('.tabs button').forEach((b) => b.addEventListener('click', () => showTab(b.dataset.tab)));

  /* ---------- scenes: one tap sets everything for a situation ---------- */
  function applyScene(sc, opts) {
    opts = opts || {};
    // Hardware mapping is opt-in. It plays the selected controller-native animation,
    // NOT the original app-generated scene animation. No timers/RGB writes are started.
    if (Number.isInteger(sc.hardwareMode) && sc.hardwareMode >= P.MODE_FIRST && sc.hardwareMode <= P.MODE_LAST) {
      if (!S.on) setPower(true);
      stopDriver(); cancelRamp(); clearInterval(fadeT); fadeT = null;
      setSleep(0);
      activeMode = sc.hardwareMode; activeScene = sc.id; curSeqId = null;
      S.lastHardwareMode = activeMode; save();
      link.send(P.mode(activeMode), 'mode');
      link.send(P.speed(S.speed), 'speed');
      renderModes(); render(); renderScenes();
      toast(sc.name + ': hardware mode ' + activeMode);
      return;
    }
    if (!S.on) setPower(true);
    S.br = sc.br; rampBright(sc.br, S.fadeMs);
    if (!opts.noTimer) setSleep(sc.sleep || 0);
    if (sc.type === 'color') {
      const c = hex2rgb(sc.color); const hs = rgb2hsv(c[0], c[1], c[2]);
      stopDriver(); activeMode = null; renderModes(); S.h = hs[0]; S.s = hs[1]; fadeColor(curRGB(), S.fadeMs); render();
    } else if (sc.type === 'white') {
      stopDriver(); activeMode = null; renderModes(); S.warm = sc.warm; $('#warm').value = sc.warm;
      link.send(P.whiteTemp(100 - sc.warm, sc.warm), 'white');
      paint(sc.warm < 50 ? [255, 190, 120] : [200, 220, 255], S.br / 100); render();
    } else if (sc.type === 'seq') {
      const q = S.seqs.find((x) => x.id === sc.seq);
      if (!q) return toast('The effect for this scene was deleted');
      playSeq(q);
    } else if (sc.type === 'mode') {
      runMode(sc.mode);
    } else if (sc.type === 'music') {
      S.musicStyle = sc.style || 'pulse';
      $$('[data-ms]').forEach((x) => x.setAttribute('aria-pressed', String(x.dataset.ms === S.musicStyle)));
      startMusic();
    }
    activeScene = sc.id; render(); renderScenes(); save();
  }
  // Optional hardware pattern shuffle; standard time-of-day Auto remains the default.
  let lastAutoMode = null, autoModeAt = 0;
  function runAutoModes(force) {
    if (!S.auto || !S.on || S.autoStyle !== 'modes' || !link.ready) return;
    const now = Date.now();
    if (!force && now - autoModeAt < S.autoInterval * 1000) return;
    const favorites = Object.keys(S.modeFav).filter(k => S.modeFav[k] && +k >= P.MODE_FIRST && +k <= P.MODE_LAST).map(Number);
    const pool = favorites.length ? favorites : Array.from({length:P.MODE_LAST-P.MODE_FIRST+1}, (_,i)=>P.MODE_FIRST+i);
    const choices = pool.filter(x=>x !== lastAutoMode);
    const selected = (choices.length ? choices : pool)[Math.floor(Math.random()*(choices.length || pool.length))];
    stopDriver(); activeMode = selected; lastAutoMode = selected; autoModeAt = now;
    S.lastHardwareMode = selected; save();
    link.send(P.mode(selected), 'mode'); link.send(P.speed(S.speed), 'speed');
    renderModes(); render(); toast('Smart Auto: ' + modeLabel(selected));
  }
  const autoId = () => { const h = new Date().getHours(); return h >= 6 && h < 9 ? 'morning' : h >= 9 && h < 17 ? 'focus' : h >= 17 && h < 20 ? 'dinner' : h >= 20 && h < 23 ? 'relax' : 'sleep'; };
  let lastAuto = null;
  function runAuto(force) {
    if (!S.auto || !S.on || !link.ready) return;
    if (S.autoStyle === 'modes') return runAutoModes(force);
    const id = autoId(); if (id === lastAuto && !force) return;
    const sc = S.scenes.find((x) => x.id === id); if (!sc) return;
    lastAuto = id; applyScene(sc, { noTimer: true }); toast('Auto: ' + sc.name);
  }
  setInterval(() => runAuto(false), 5000);
  $('#autoStyle').value = S.autoStyle;
  $('#autoStyle').addEventListener('change',e=>{ S.autoStyle=e.target.value; lastAuto=null; autoModeAt=0; save(); if(S.auto)runAuto(true); });
  $('#autoInterval').value = S.autoInterval;
  $('#autoIntervalOut').textContent = S.autoInterval + ' s';
  $('#autoInterval').addEventListener('input',e=>{S.autoInterval=+e.target.value;$('#autoIntervalOut').textContent=S.autoInterval+' s';save();});
  $('#preserveHardware').checked = !!S.preserveHardware;
  $('#preserveHardware').addEventListener('change',e=>{S.preserveHardware=e.target.checked;save();});

  function mapSceneHardware(sc) {
    const options = Array.from({length: P.MODE_LAST - P.MODE_FIRST + 1}, (_, i) => P.MODE_FIRST + i);
    openDialog(`<h3>${esc(sc.name)}: Hardware mode</h3>
      <p class="hint">Link this scene to a controller-native animation. The original Candle/Party/Sleep animation is NOT copied to controller memory. The chosen numbered mode replaces that scene while linked.</p>
      <label class="field"><span>Controller pattern</span><select id="sceneHardware" class="text">
        <option value="">Original phone-driven scene (default)</option>
        ${options.map(id => `<option value="${id}" ${sc.hardwareMode === id ? 'selected' : ''}>${id} — ${esc(modeLabel(id))}${S.modePersistent[id] ? ' (offline-tested)' : ' (untested)'}</option>`).join('')}
      </select></label>
      <p class="hint">Start with tested Mode 128. After choosing another mode, close the app and power cycle the strip to confirm persistence. Smart Auto switching still needs the app connected.</p>
      <div class="dlgActs"><button class="btn ghost" value="cancel">Cancel</button><button class="btn main" type="button" id="saveSceneHardware">Save mapping</button></div>`, f => {
        f.querySelector('#saveSceneHardware').addEventListener('click', () => {
          const chosen = f.querySelector('#sceneHardware').value;
          if (chosen) sc.hardwareMode = Number(chosen);
          else delete sc.hardwareMode;
          save(); closeDialog(); renderScenes();
          toast(chosen ? sc.name + ' linked to Mode ' + chosen : sc.name + ': original mode restored');
        });
      });
  }
  function renderScenes() {
    renderCar();
    const box = $('#scenes'); if (!box) return; box.innerHTML = '';
    const auto = document.createElement('button');
    auto.type = 'button'; auto.className = 'scene auto'; auto.textContent = 'Auto'; auto.setAttribute('aria-pressed', String(!!S.auto));
    auto.title = 'Picks a scene by time of day';
    auto.addEventListener('click', () => {
      S.auto = !S.auto; save();
      if (S.auto) { if (!link.ready) { S.auto = false; return toast('Connect the strip first'); } lastAuto = null; runAuto(true); }
      else toast('Auto is off');
      renderScenes();
    });
    box.appendChild(auto);
    S.scenes.forEach((sc) => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'scene'; b.textContent = sc.name; b.setAttribute('aria-pressed', String(activeScene === sc.id));
      b.addEventListener('click', () => { S.auto = false; applyScene(sc); });
      box.appendChild(b);
    });
    const list = $('#sceneList'); if (!list) return; list.innerHTML = '';
    S.scenes.forEach((sc, i) => {
      const r = document.createElement('div'); r.className = 'sceneRow';
      const nativeHint = Number.isInteger(sc.hardwareMode) ? ' · HW ' + sc.hardwareMode + (S.modePersistent[sc.hardwareMode] ? ' ✓ tested' : ' ? untested') : ' · phone-driven';
      r.innerHTML = '<span>' + esc(sc.name + nativeHint) + '</span><div><button type="button" class="lnk" aria-label="Copy shortcut link for ' + esc(sc.name) + '">Link</button><button type="button" class="map" aria-label="Link a hardware mode to ' + esc(sc.name) + '">Hardware</button><button type="button" class="del" aria-label="Delete ' + esc(sc.name) + '">×</button></div>';
      r.querySelector('.map').addEventListener('click', () => mapSceneHardware(sc));
      r.querySelector('.del').addEventListener('click', () => { S.scenes.splice(i, 1); save(); renderScenes(); });
      r.querySelector('.lnk').addEventListener('click', () => {
        const url = location.href.split('#')[0] + '#scene=' + sc.id;
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(url).then(() => toast('Link copied. Open it in Chrome and add it to your home screen.'), () => { $('#backup').value = url; toast('Copy the link from the box below'); });
        else { $('#backup').value = url; toast('Copy the link from the box below'); }
      });
      list.appendChild(r);
    });
  }
  /* ---------- safe offline-tested hardware-to-scene mapper ---------- */
  const mapSceneSelect = $('#persistentScene');
  const mapModeSelect = $('#persistentMode');
  const mapStatus = $('#persistentMapStatus');
  function renderPersistentMapper() {
    const prevScene = mapSceneSelect.value;
    const prevMode = mapModeSelect.value;
    mapSceneSelect.innerHTML = '';
    S.scenes.forEach(sc => {
      const o = document.createElement('option'); o.value = sc.id;
      o.textContent = sc.name + (Number.isInteger(sc.hardwareMode) ? ' → Mode ' + sc.hardwareMode : ' (original)');
      mapSceneSelect.appendChild(o);
    });
    if (S.scenes.some(sc => sc.id === prevScene)) mapSceneSelect.value = prevScene;
    mapModeSelect.innerHTML = '';
    const verified = Object.keys(S.modePersistent || {})
      .filter(k => S.modePersistent[k] && Number(k) >= P.MODE_FIRST && Number(k) <= P.MODE_LAST)
      .map(Number).sort((a,b)=>a-b);
    verified.forEach(id => {
      const o = document.createElement('option'); o.value = String(id);
      o.textContent = id + ' — ' + modeLabel(id) + ' (offline-tested)';
      mapModeSelect.appendChild(o);
    });
    if (verified.some(id => String(id) === prevMode)) mapModeSelect.value = prevMode;
    mapModeSelect.disabled = !verified.length;
    $('#persistentLink').disabled = !verified.length || !S.scenes.length;
    mapStatus.textContent = verified.length
      ? verified.length + ' offline-tested mode(s). Mapping changes only the chosen scene.'
      : 'No verified hardware modes. Test a numbered mode offline, then mark it via Effects → Built-in → Rename.';
  }
  mapSceneSelect.addEventListener('change', () => {
    const sc = S.scenes.find(q => q.id === mapSceneSelect.value);
    if (sc && Number.isInteger(sc.hardwareMode) && S.modePersistent[sc.hardwareMode])
      mapModeSelect.value = String(sc.hardwareMode);
  });
  $('#persistentLink').addEventListener('click', () => {
    const sc = S.scenes.find(q => q.id === mapSceneSelect.value);
    const id = Number(mapModeSelect.value);
    if (!sc || !S.modePersistent[id] || id < P.MODE_FIRST || id > P.MODE_LAST) {
      mapStatus.textContent = 'Select an offline-tested hardware mode first.'; return;
    }
    if (!confirm(sc.name + ' will now play Mode ' + id + ' instead of its original animation. Save mapping?')) return;
    sc.hardwareMode = id; save(); renderScenes(); renderPersistentMapper();
    mapStatus.textContent = sc.name + ' mapped to hardware Mode ' + id + '. Play it, close the app, and power cycle to test.';
  });
  $('#persistentRestore').addEventListener('click', () => {
    const sc = S.scenes.find(q => q.id === mapSceneSelect.value);
    if (!sc) return;
    delete sc.hardwareMode; save(); renderScenes(); renderPersistentMapper();
    mapStatus.textContent = sc.name + ': original phone-driven scene restored.';
  });
  $('#persistentPlay').addEventListener('click', () => {
    const sc = S.scenes.find(q => q.id === mapSceneSelect.value);
    if (!sc) return;
    if (!link.ready) { mapStatus.textContent = 'Connect the LED strip first.'; return; }
    S.auto = false; applyScene(sc);
    mapStatus.textContent = sc.name + ' playback requested. Verify the physical LED strip.';
  });
  renderPersistentMapper();
  /* ---------- car mode: big targets, very dim screen ---------- */
  const CAR_IDS = ['c-night', 'c-cruise', 'c-chill', 'party'];
  function renderCar() {
    const grid = $('#carGrid'); if (!grid) return; grid.innerHTML = '';
    CAR_IDS.map((id) => S.scenes.find((x) => x.id === id)).filter(Boolean).forEach((sc) => {
      const b = document.createElement('button'); b.type = 'button'; b.textContent = sc.name; b.setAttribute('aria-pressed', String(activeScene === sc.id && S.on));
      b.addEventListener('click', () => { S.auto = false; applyScene(sc); });
      grid.appendChild(b);
    });
    // Reuse starred built-in effects as large car-mode quick actions.
    const starred = Object.keys(S.modeFav).filter(id => S.modeFav[id] && +id >= P.MODE_FIRST && +id <= P.MODE_LAST).slice(0, 6);
    starred.forEach(id => {
      const b = document.createElement('button'); b.type = 'button'; b.textContent = '★ ' + modeLabel(+id);
      b.setAttribute('aria-pressed', String(activeMode === +id && S.on));
      b.addEventListener('click', () => { S.auto = false; runMode(+id); renderCar(); });
      grid.appendChild(b);
    });
    $('#carFavCount').textContent = starred.length ? starred.length + ' starred modes available' : 'Star modes in Effects → Built-in → Rename to add shortcuts here.';
  }
  $('#btnCar').addEventListener('click' , () => { $('#car').hidden = false; renderCar(); });
  $('#carExit').addEventListener('click', () => { $('#car').hidden = true; });
  const carStep = (d) => { S.br = clamp(S.br + d, 5, 100); rampBright(S.br, 300); render(); save(); };
  $('#carUp').addEventListener('click', () => carStep(10));
  $('#carDown').addEventListener('click', () => carStep(-10));
  $('#carOff').addEventListener('click', () => { stopDriver(); activeScene = null; setPower(false); renderScenes(); });

  $('#sceneSave').addEventListener('click', () => {
    openDialog(`<h3>Save scene</h3>
      <label class="field"><span>Name</span><input class="text" name="n" maxlength="16" placeholder="Gaming"></label>
      <p class="hint">Saves what the strip is doing now, plus brightness${sleepEnd > Date.now() ? ' and the sleep timer' : ''}.</p>
      <div class="dlgActs"><button class="btn ghost" value="cancel">Cancel</button><button class="btn main" id="okBtn" value="ok">Save</button></div>`,
    (f) => f.querySelector('#okBtn').addEventListener('click', (e) => {
      e.preventDefault();
      const name = f.n.value.trim(); if (!name) return toast('Give the scene a name');
      const sc = { id: 'u' + Date.now(), name, br: S.br };
      if (curSeqId) { sc.type = 'seq'; sc.seq = curSeqId; }
      else if (driver && driver.label === 'Listening…') { sc.type = 'music'; sc.style = S.musicStyle; }
      else if (activeMode !== null) { sc.type = 'mode'; sc.mode = activeMode; }
      else { sc.type = 'color'; sc.color = rgb2hex(...curRGB()); }
      if (sleepEnd > Date.now()) sc.sleep = Math.max(1, Math.round((sleepEnd - Date.now()) / 60000));
      S.scenes.push(sc); save(); renderScenes(); closeDialog(); toast('Saved scene ' + name);
    }));
  });
  $('#sceneReset').addEventListener('click', () => { S.scenes = DEFAULT_SCENES(); save(); renderScenes(); toast('Scenes reset'); });

  /* ---------- sunset dimming ---------- */
  function sunTimes(lat, lon, d) {
    const rad = Math.PI / 180;
    const n = Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - Date.UTC(d.getFullYear(), 0, 0)) / 864e5);
    const g = 2 * Math.PI / 365 * (n - 1);
    const eqt = 229.18 * (0.000075 + 0.001868 * Math.cos(g) - 0.032077 * Math.sin(g) - 0.014615 * Math.cos(2 * g) - 0.040849 * Math.sin(2 * g));
    const dec = 0.006918 - 0.399912 * Math.cos(g) + 0.070257 * Math.sin(g) - 0.006758 * Math.cos(2 * g) + 0.000907 * Math.sin(2 * g) - 0.002697 * Math.cos(3 * g) + 0.00148 * Math.sin(3 * g);
    const ha = Math.acos(Math.cos(90.833 * rad) / (Math.cos(lat * rad) * Math.cos(dec)) - Math.tan(lat * rad) * Math.tan(dec)) / rad;
    const base = Date.UTC(d.getFullYear(), d.getMonth(), d.getDate());
    return { rise: new Date(base + (720 - 4 * (lon + ha) - eqt) * 60000), set: new Date(base + (720 - 4 * (lon - ha) - eqt) * 60000) };
  }
  const fmtT = (d) => d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  function sunInfo() {
    const el = $('#sunInfo'); if (!el) return;
    if (S.sunDim && S.geo) { const t = sunTimes(S.geo.lat, S.geo.lon, new Date()); el.textContent = isFinite(t.set) ? 'Sunset ' + fmtT(t.set) + ', sunrise ' + fmtT(t.rise) + ' today.' : 'No sunset today at this location.'; }
    else el.textContent = 'Uses your location once to work out sunset. It stays on your phone.';
  }
  function sunCheck() {
    if (!S.sunDim || !S.geo || !link.ready) return;
    const t = sunTimes(S.geo.lat, S.geo.lon, new Date()), now = Date.now();
    const night = isFinite(t.set) && isFinite(t.rise) ? (now < t.rise.getTime() || now > t.set.getTime()) : false;
    const st = night ? 'night' : 'day';
    if (st === S.sunState) return;
    S.sunState = st;
    if (night) { S.dayBr = S.br; S.br = Math.min(S.br, S.sunCap); } else { S.br = S.dayBr; }
    if (S.on) rampBright(S.br, Math.max(S.fadeMs, 1000) * 2);
    render(); save(); toast(night ? 'Sunset: dimmed to ' + S.br + '%' : 'Daytime: brightness restored');
  }
  setInterval(sunCheck, 2 * 60 * 1000);
  $('#sunDim').addEventListener('change', (e) => {
    S.sunDim = e.target.checked; save();
    if (!S.sunDim) { sunInfo(); return; }
    if (S.geo) { sunInfo(); sunCheck(); return; }
    if (!navigator.geolocation) { toast('This browser has no location'); e.target.checked = S.sunDim = false; return; }
    navigator.geolocation.getCurrentPosition(
      (p) => { S.geo = { lat: +p.coords.latitude.toFixed(2), lon: +p.coords.longitude.toFixed(2) }; save(); sunInfo(); sunCheck(); },
      () => { toast('Location permission was denied'); e.target.checked = S.sunDim = false; save(); sunInfo(); });
  });
  $('#sunCap').addEventListener('input', (e) => { S.sunCap = +e.target.value; $('#sunCapOut').textContent = S.sunCap + '%'; save(); });

  /* ---------- smooth change setting ---------- */
  $$('#fadeSeg button').forEach((b) => b.addEventListener('click', () => {
    S.fadeMs = +b.dataset.fade; save();
    $$('#fadeSeg button').forEach((x) => x.setAttribute('aria-pressed', String(x === b)));
  }));

  /* ---------- home screen shortcuts: index.html#scene=<id> ---------- */
  let pendingScene = null;
  function runSceneId(id) {
    if (id === 'off') { setPower(false); renderScenes(); return; }
    const sc = S.scenes.find((x) => x.id === id);
    if (sc) { S.auto = false; applyScene(sc); } else toast('That scene no longer exists');
  }
  function runHash() {
    const m = /scene=([\w-]+)/.exec(location.hash); if (!m) return;
    if (!link.ready) { pendingScene = m[1]; toast('Tap Connect strip to run this scene'); return; }
    runSceneId(m[1]);
  }
  window.addEventListener('hashchange', runHash);

  /* ---------- backup to a file ---------- */
  $('#expFile').addEventListener('click', () => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(S, null, 1)], { type: 'application/json' }));
    a.download = 'melk-studio-settings.json'; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 3000); toast('Settings saved to a file');
  });
  $('#impFile').addEventListener('click', () => $('#impInput').click());
  $('#impInput').addEventListener('change', async (e) => {
    const f = e.target.files[0]; if (!f) return;
    $('#backup').value = await f.text(); $('#impBtn').click(); e.target.value = '';
  });

  function renderAll() {
    $('#sp').value = S.speed; $('#spOut').textContent = S.speed + '%'; $('#sen').value = S.sens; $('#senOut').textContent = S.sens + '%';
    $('#warm').value = S.warm; $('#flowSec').value = S.flowSec; $('#flowOut').textContent = fmtSec(S.flowSec); $('#showAll').checked = !!S.showAll;
    $$('#fadeSeg button').forEach((b) => b.setAttribute('aria-pressed', String(+b.dataset.fade === S.fadeMs)));
    $('#sunDim').checked = !!S.sunDim; $('#sunCap').value = S.sunCap; $('#sunCapOut').textContent = S.sunCap + '%'; sunInfo();
    renderPalette(); renderModes(); renderSeqs(); renderScenes(); render(); showTab(S.tab || 'color');
  }
  renderAll();
  runHash();
})();
