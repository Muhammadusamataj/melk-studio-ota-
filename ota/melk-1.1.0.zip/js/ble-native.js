/* Native Bluetooth adapter for the Capacitor APK.
 * Calls the bluetooth-le plugin with the argument shapes it expects:
 *   connect({ deviceId }), disconnect({ deviceId }),
 *   writeWithoutResponse({ deviceId, service, characteristic, value: <hex string> }).
 * Does nothing in a normal browser (the web preview keeps using Web Bluetooth). */
(function (g) {
  'use strict';
  if (!g.Capacitor || !g.Capacitor.isNativePlatform || !g.Capacitor.isNativePlatform()) return;

  const P = g.Melk.protocol;
  const Base = g.Melk.Link;
  const KEY = 'melk.native.deviceId';
  const RETRY_MS = [800, 1500, 3000, 5000, 8000, 12000];
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const hex = (bytes) => Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');

  function ble() {
    const p = (g.Capacitor.Plugins && g.Capacitor.Plugins.BluetoothLe) ||
      (typeof g.Capacitor.registerPlugin === 'function'
        ? g.Capacitor.registerPlugin('BluetoothLe') : null);
    if (!p) throw new Error('Bluetooth plugin nahi mila. npx cap sync ke baad APK dobara build karein.');
    return p;
  }

  class NativeLink extends Base {
    constructor() {
      super();
      this.deviceId = null;
      this.listener = null;
      this._manual = false;
      this.reconnecting = false;
      this._gen = 0;   // bumped by every connect/disconnect, cancels older retry loops
      this.gap = 40;
      // App khulte hi pichli strip se khud judne ki koshish
      const saved = localStorage.getItem(KEY);
      if (saved) { this.deviceId = saved; setTimeout(() => this._reconnect(), 1200); }
    }
    get supported() { return true; }

    async _init() { await ble().initialize({ androidNeverForLocation: true }); }

    async _open(id, name) {
      await ble().connect({ deviceId: id });
      if (this.listener) { try { await this.listener.remove(); } catch (e) { /* already gone */ } }
      this.listener = await ble().addListener('disconnected|' + id, () => this._dropped());
      this.deviceId = id;
      localStorage.setItem(KEY, id);
      this._set('connected', name || 'LED strip');
    }

    async connect() {
      this._gen++;               // cancel any background retry loop
      this.reconnecting = false;
      this._manual = false;
      this._set('connecting');
      try {
        await this._init();      // asks for Bluetooth permission if not yet granted
        const dev = await ble().requestDevice({ namePrefix: P.NAME_PREFIX, optionalServices: [P.SERVICE] });
        const id = dev && (dev.deviceId || dev.id);
        if (!id) throw new Error('Strip ka ID nahi mila. Dobara try karein.');
        await this._open(id, dev.name);
      } catch (e) {
        this._set('idle', '');
        const msg = (e && e.message) || '';
        if (!/cancel/i.test(msg)) this.dispatchEvent(new CustomEvent('error', { detail: e }));
      }
    }

    _dropped() {
      this.queue.length = 0;
      if (this._manual || !this.deviceId) { this._set('idle', ''); return; }
      this._reconnect();
    }

    async _reconnect() {
      if (this.reconnecting || !this.deviceId) return;
      const my = ++this._gen;
      this.reconnecting = true;
      this._set('connecting');
      try {
        await this._init();      // permission prompt happens here on launch too
      } catch (e) {
        this.reconnecting = false;
        this._set('idle', '');
        this.dispatchEvent(new CustomEvent('error', { detail: e }));
        return;
      }
      for (const d of RETRY_MS) {
        await sleep(d);
        if (my !== this._gen || this._manual || !this.deviceId) return;   // cancelled
        try {
          await this._open(this.deviceId);
          this.reconnecting = false;
          this.dispatchEvent(new CustomEvent('restored'));
          return;
        } catch (e) { /* strip not in range yet */ }
      }
      if (my !== this._gen) return;
      this.reconnecting = false;
      this._set('idle', '');
      this.dispatchEvent(new CustomEvent('lost'));
    }

    resume() { if (this.state === 'idle' && this.deviceId && !this._manual) this._reconnect(); }

    async disconnect() {
      this._manual = true;
      this._gen++;
      this.reconnecting = false;
      const id = this.deviceId;
      this.deviceId = null;
      localStorage.removeItem(KEY);
      if (id) { try { await ble().disconnect({ deviceId: id }); } catch (e) { /* ignore */ } }
      this._set('idle', '');
    }

    startDemo() { this._set('demo', 'Demo strip'); }

    async _pump() {
      if (this.pumping) return;
      this.pumping = true;
      while (this.queue.length) {
        const { bytes } = this.queue.shift();
        try {
          if (this.state === 'connected' && this.deviceId) {
            await ble().writeWithoutResponse({
              deviceId: this.deviceId,
              service: P.SERVICE,
              characteristic: P.CHAR,
              value: hex(bytes),
            });
          }
          this.dispatchEvent(new CustomEvent('tx', { detail: P.hex(bytes) }));
        } catch (e) {
          this.dispatchEvent(new CustomEvent('error', { detail: e }));
        }
        await sleep(this.gap);
      }
      this.pumping = false;
    }
  }
  g.Melk.Link = NativeLink;
})(window);
