/* MELK Studio self-hosted OTA. No Bluetooth code is changed here. */
(function(g) {
  'use strict';
  const APP_VERSION = '1.1.2';
  const UPDATE_URL = 'https://muhammadusamataj.github.io/melk-studio-ota-/ota/melk-version.json';
  const el = id => document.getElementById(id);
  const native = !!(g.Capacitor && typeof g.Capacitor.isNativePlatform === 'function' && g.Capacitor.isNativePlatform());
  const updater = native && g.Capacitor.Plugins && g.Capacitor.Plugins.CapacitorUpdater;
  let busy = false, available = null;
  function status(message) { const e = el('otaStatus'); if (e) e.textContent = message; }
  function setBusy(b) { busy = b; const e = el('otaCheck'); if (e) e.disabled = b; const i = el('otaInstall'); if (i) i.disabled = b; }
  function newer(current, remote) {
    const a=String(current).split('.').map(Number), b=String(remote).split('.').map(Number);
    for (let i=0;i<3;i++) if ((a[i]||0)!==(b[i]||0)) return (b[i]||0)>(a[i]||0);
    return false;
  }
  async function runningVersion() {
    if (!updater) return APP_VERSION;
    try { const r=await updater.current(); return r && r.bundle && r.bundle.version || APP_VERSION; }
    catch (_) { return APP_VERSION; }
  }
  async function check(manual) {
    if (busy) return;
    setBusy(true);
    const install=el('otaInstall'); if (install) install.hidden=true;
    available=null;
    status('Checking GitHub for updates…');
    try {
      // Prefer Capacitor's native HTTP bridge on Android to avoid WebView CORS.
      // This uses HTTPS and never changes the BLE scanning/connection modules.
      let info;
      const http = native && g.Capacitor && g.Capacitor.Plugins && g.Capacitor.Plugins.CapacitorHttp;
      if (http && typeof http.get === 'function') {
        const res = await http.get({
          url: UPDATE_URL,
          headers: { 'Accept': 'application/json', 'Cache-Control': 'no-cache' },
          connectTimeout: 12000,
          readTimeout: 12000
        });
        if (res.status < 200 || res.status >= 300) throw new Error('Server HTTP '+res.status);
        info = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
      } else {
        const res = await fetch(UPDATE_URL, {cache:'no-store'});
        if (!res.ok) throw new Error('Server HTTP '+res.status);
        info = await res.json();
      }
      if (!info || !/^\d+\.\d+\.\d+$/.test(String(info.version)) ||
        !/^https:\/\//.test(String(info.url)) ||
        new URL(info.url).origin !== new URL(UPDATE_URL).origin) throw new Error('Invalid update manifest');
      const current=await runningVersion();
      if (!newer(current,info.version)) { status('Up to date (v'+current+').'); return; }
      available=info;
      if (!updater) { status('v'+info.version+' is available, but this APK has no native OTA updater. Rebuild/install an OTA-enabled APK once.'); return; }
      status('New web update v'+info.version+' available. Install only when you are not controlling the strip.');
      if (install) install.hidden=false;
    } catch(e) { status('Update check failed: '+(e.message||e)); if (!manual) console.warn('[MELK OTA]',e); }
    finally {setBusy(false);}
  }
  async function install() {
    if (!updater || !available || busy) return;
    const info=available;
    if (!g.confirm('Download MELK Studio v'+info.version+'? Apply after restarting the app.')) return;
    setBusy(true);
    const progress=el('otaProgress');
    if (progress) {progress.hidden=false;progress.removeAttribute('value');}
    status('Downloading update… Keep the app open.');
    try {
      // Native updater requires the SHA-256 checksum of the downloaded ZIP.
      // Read the exact value from the trusted manifest, not from local guesswork.
      if (!/^[a-f0-9]{64}$/i.test(String(info.sha256 || ''))) {
        throw new Error('Update manifest is missing a valid SHA-256 checksum');
      }
      const bundle=await updater.download({url:info.url,version:info.version,checksum:info.sha256});
      if (!bundle || !bundle.id) throw new Error('Updater returned no bundle ID');
      await updater.next({id:bundle.id});
      status('v'+info.version+' downloaded. Close and reopen the app to apply.');
      const i=el('otaInstall'); if(i)i.hidden=true;
    } catch(e) {status('Update failed; current app remains active. '+(e.message||e));}
    finally {if(progress)progress.hidden=true;setBusy(false);}
  }
  function init() {
    if(el('otaVersion'))el('otaVersion').textContent='v'+APP_VERSION;
    if(el('otaCapability'))el('otaCapability').textContent=updater?'Available':'Not installed in APK';
    if(el('otaCheck'))el('otaCheck').addEventListener('click',()=>check(true));
    if(el('otaInstall'))el('otaInstall').addEventListener('click',install);
    if(updater) {
      Promise.resolve(updater.notifyAppReady()).catch(e=>console.warn('[MELK OTA] notifyAppReady:',e));
    }
    // Automatic check is informative only; no surprise downloads or BLE interruption.
    if(native) g.setTimeout(()=>check(false),10000);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
  g.MelkOta={check:()=>check(true),APP_VERSION};
})(window);
