/* MELK LED protocol — decoded from Magic Lantern 6.11.10 (wl.smartled.rgb)
 * Every command is a 9-byte packet: 0x7E ... 0xEF, written to
 * service 0xFFF0 / characteristic 0xFFF3.
 */
(function (g) {
  'use strict';
  const clamp = (v, a, b) => Math.max(a, Math.min(b, Math.round(Number(v) || 0)));
  const pkt = (a) => Uint8Array.from(a);

  const protocol = {
    SERVICE: '0000fff0-0000-1000-8000-00805f9b34fb',
    CHAR: '0000fff3-0000-1000-8000-00805f9b34fb',
    NAME_PREFIX: 'MELK',
    MODE_FIRST: 128, // inferred range, see docs/PROTOCOL.md
    MODE_LAST: 155,

    power: (on) => pkt([0x7e, 0x04, 0x04, on ? 1 : 0, 0x00, on ? 1 : 0, 0xff, 0x00, 0xef]),
    color: (r, g, b) => pkt([0x7e, 0x07, 0x05, 0x03, clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255), 0x10, 0xef]),
    brightness: (pct) => pkt([0x7e, 0x04, 0x01, clamp(pct, 0, 100), 0xff, 0xff, 0xff, 0x00, 0xef]),
    speed: (pct) => pkt([0x7e, 0x04, 0x02, clamp(pct, 0, 100), 0xff, 0xff, 0xff, 0x00, 0xef]),
    mode: (id) => pkt([0x7e, 0x05, 0x03, clamp(id, 0, 255), 0x06, 0xff, 0xff, 0x00, 0xef]),
    // Native scene (verified in Magic Lantern 6.11.10 BluetoothLEService.changeScene):
    // 7E 05 31 [SCENE 1..28] 07 FF FF 01 EF. Scene names come from modes_group8 in the APK.
    scene: (id) => pkt([0x7e, 0x05, 0x31, clamp(id, 1, 28), 0x07, 0xff, 0xff, 0x01, 0xef]),
    NATIVE_SCENES: {1:'Sunrise',2:'Sunset',3:'Birthday',4:'Candlelight',5:'Fireworks',6:'Party',7:'Datiny',8:'Starry sky',9:'Romantic',10:'Disco',11:'Rainbow',12:'Movie',13:'Christmas',14:'Flowing',15:'Sleeping',16:'Ocean',17:'Forest',18:'Reading',19:'Working',20:'Dazzle',21:'Gentle',22:'Wedding',23:'Snow',24:'Fire',25:'Lightning',26:"Valentine's Day",27:'Hallowmas',28:'Warnning'},
    whiteTemp: (warm, cold) => pkt([0x7e, 0x06, 0x05, 0x02, clamp(warm, 0, 100), clamp(cold, 0, 100), 0xff, 0x08, 0xef]),

    hex: (u8) => Array.from(u8, (x) => x.toString(16).padStart(2, '0')).join(' ').toUpperCase(),
  };
  g.Melk = g.Melk || {};
  g.Melk.protocol = protocol;
})(typeof window !== 'undefined' ? window : globalThis);
